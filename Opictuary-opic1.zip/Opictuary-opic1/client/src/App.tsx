function App() {
  return (
    <div style={{ padding: "20px", textAlign: "center" }}>
      <h1>Opictuary</h1>
      <p>Digital Memorial Platform</p>
    </div>
  );
}

export default App;
