function App() {
  return (
    <div style={{ 
      display: 'flex', 
      flexDirection: 'column', 
      alignItems: 'center', 
      justifyContent: 'center', 
      minHeight: '100vh',
      fontFamily: 'system-ui, sans-serif',
      backgroundColor: '#1a1a2e',
      color: 'white'
    }}>
      <h1>Opictuary</h1>
      <p>Digital Memorials Platform</p>
      <p>Honor and preserve the memory of your loved ones</p>
    </div>
  );
}

export default App;
